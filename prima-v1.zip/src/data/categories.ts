export const categories = [
     {id : 1, title: "Calzado" },
     {id : 2, title :  "Comidas y postres"},
     {id : 3, title :  "Decoraciones,  fiestas y toldos"},
     {id : 4, title :  "Florerías"},
     {id : 5, title :  "Joyería y artesanía"},
     {id : 6, title :  "Maquillaje y peluquería"},
     {id : 7, title :  "Moda, satrería y accesorios"},
     {id : 8, title :  "Movilidad"},
     {id : 9, title :  "Muebles"},
     {id : 10, title :  "Panaderías y cafetería"},
     {id : 11, title :  "Servicios para el hogar"},
     {id : 12, title :  "Servicios Profesionales"},
     {id : 13, title :  "Terapia física y de lenguaje"},
     {id : 14, title :  "Turismo"},
     {id : 15, title :  "Tutorías y clases"},
     {id : 16, title :  "Otros"}
 ];