export enum routes {
    HOME='/',
    CONTACT='/contact',
}
