This project is built with the following tools:

1. React.js
2. Typescript and
3. Tailwind Css
The test project is fully responsive on all screen sizes, and I have paid attention to all details.

A video Guide has been uploaded in the root directory to help you navigate through the 3 pages. -> https://github.com/Mbrain1/hostbeak/blob/master/video-guide.mp4